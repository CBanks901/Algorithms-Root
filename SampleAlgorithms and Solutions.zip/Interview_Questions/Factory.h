#ifndef Factory_H_
#define Factory_H_
#include "Utilities.h"
/* 
Date: August 28th, 2015
Purpose: This program uses a factory design implementation for 3 classes which are
Cars, Alcohol, and Toys. Each class is a subclass of the main class factory which is a pure
abstract class with its own methods.
Notes: 
Status: complete 
*/

#define Child(x) ( (x >= 0 && x <= 17 ) ? true : false )
#define Teen(x) ( ( x > 17 && x < 21) ? true : false )
#define Adult(x) ( (x >= 21) ? true: false )

class Factory
{
public:
	static Factory *makedecision(int age);
	static Factory* getInstance();
	int getage();
	void PrintType();
	void setAge(int age);
protected:
	string type;
	virtual void setType(string type) = 0;
private:
	static Factory* instance;
	int age;
};

struct ToyMaterials
{
	static string rubber;
	static string plastic;
	static string metal;
};

// Ages 3 to 17
class Toy: public Factory
{
public:
	Toy();
	Toy(string make);
	void setType(string type);
private:
	string make;
	void PrintMake();
	void setMake(string make);
};

// Ages 18 to 21
class Car: public Factory
{
public:
	Car();
	Car(string make);
	void setType(string type);
private:
	string make;
	void PrintMake();
	void setMake(string make);
};

// Ages 21 and above
class Alcohol: public Factory
{
public:
	Alcohol();
	Alcohol(string a);
	void setType(string type);
private:
	string flavor;
	void PrintBevarage();
	void setFlavor(string a);
};

void ExecuteFactory();
#endif