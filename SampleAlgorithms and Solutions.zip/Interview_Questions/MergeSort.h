#ifndef MergeSort_H_
#define MergeSort_H_
#include "Utilities.h"

class MergeSort
{
public:
	MergeSort();
	MergeSort(const MergeSort&);
	~MergeSort();
	vector<int> Mergesort(vector<int> &left, vector<int> &right);
	vector<char> Mergersort(vector<char> &left, vector<char> &right);
private:
	void Merge(vector<int> &left, vector<int> &right, int pivot, int pivotL, int pivotR);
};

void ExecuteMergeSort();
void ExecuteCharMergerSort();
#endif