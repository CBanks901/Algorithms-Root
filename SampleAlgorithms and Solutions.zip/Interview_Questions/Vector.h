#ifndef Vector_H_
#define Vector_H_
#include "Utilities.h"
/*
Name: Christian Banks
Date: 08/31/2015
Purpose: Creates a class and uses vectors as the implementation style.
Notes: This class gathers input from the user such as what is their favorite console and such
status: complete
*/

class FavoriteConsoles
{
public:
	FavoriteConsoles();
	FavoriteConsoles(string *, int);
	FavoriteConsoles(vector<string>, int);
	~FavoriteConsoles();
	void PrintFavorites();
	string getValue(int i);
	int getIndex(string);
private:
	vector<string> console;
	bool checkIterator(vector<string>::const_iterator);
};

void ExecuteVector();

#endif