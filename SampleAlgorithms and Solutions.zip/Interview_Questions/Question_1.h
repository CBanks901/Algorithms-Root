#include "Utilities.h"

/*
	This function determines if all the characters in a string are unique
*/
bool unique_characters(string sample)
{
	
	// create a character array based on the length of the string and copy the strings contents
	int i = 0;
	char* copy = new char[sample.length()];
	for (i; i < sample.length(); i++)
	{
		// check to see if any letter is upper case.. if so then convert it to lower case
		if (isupper(sample[i]) )
			sample[i] = tolower(sample[i]);

		copy[i] = sample[i];
		cout << "Character: " << copy[i] << endl;
	}

	for (int l = 0; l < sample.length(); l++)
	{
		// special case for the first scenario only
		if (copy[l] == sample.front() )
		{
			for (int k = 1; k < sample.length(); k++)
			{
				if (copy[l] != copy[k])
					continue;	// keep going
				else if (copy[l] == copy[k])
				{
					cout << "Duplicate found: " << copy[l] << endl;
					return false;
				}
			}
		}
		else if (copy[l] != 0 && copy[l] == sample.at(l) )
		{
			int z = l + 1;
			int q = l - 1;

			// checks the forward direction for duplicates
			for (z; z < sample.length(); z++)
			{
				if (copy[l] != copy[z])
					continue;
				else if (copy[l] == copy[z])
				{
					cout << "Duplicate found: " << copy[l] << endl;
					return false;
				}
			}
		}
	}

	return true;		// if we got here that means we don't have any errors
}

// function executes the scenario for this question. Simply call this function to handle everything
void Question1Scenario()
{
	string sample;
	cout << "Please enter a string: " << endl;
	cin >> sample;							// gather input from the user
	unique_characters(sample) ? cout << "All characters are unique" << endl : 
		cout << "All characters are not unique" << endl;

	cout << "\aRepeat? Y or N?: ";		// '\a' makes a noise beep affect
	char value;
	cin >> value;

	if (value == 'Y' || value == 'y')
		{
			Question1Scenario();		// call the function to execute again
		}
	else 
	{
		return;
	}
}