#include "Queue.h"

Queue::Queue()
{
	maxsize = 5;
	myqueue = new int[maxsize];
	rear = maxsize-1;
	front = 0;
	initalize();
}

Queue::Queue(int size)
{
	maxsize = size;
	rear = maxsize-1;
	front = 0;
	myqueue = new int[maxsize];
	initalize();
}

Queue::~Queue()
{
	clear();
}

void Queue::initalize()
{
	int i = 0;
	int input;
	if (maxsize == 0)
	{
		cout << "Recreating queue." << endl;
		cout << "Please enter a size value: ";
		cin >> input;
		maxsize = input;
		myqueue = new int[maxsize];
		rear = maxsize-1;
		front = 0;
	}
	cout << "Please intialize the queue." << endl;
	do
	{
		cout << "Enter a number value: ";
		cin >> input;
		ChangeElement(i, input);
		i++;
	} while( i < maxsize );
}

void Queue::clear()
{
	while (front <= rear)
	{
		myqueue[front] = NULL;
		front++;
	}
	maxsize = 0;
	myqueue = NULL;
	delete myqueue;
	cout << "Queue cleared." << endl;
}

int Queue::getSize()
{
	return maxsize;
}

int Queue::getFront()
{
	if (myqueue[front])
		return myqueue[front];
	else 
		return NULL;
}

int Queue::getRear()
{
	if (myqueue[rear] )
		return myqueue[rear];
	else
		return NULL;
}

void Queue::PrintQueue()
{
	if (myqueue == NULL)
	{
		cout << "Queue no longer exists." << endl;
	}
	else
	{
		cout << "Printing Queue... " << endl;
		if (isEmpty() )
		{
			cout << "Queue has no elements to print." << endl;
		}
		else
			for (int i = front; i <= rear; i++)
			{
				cout << i+1 << ": " << myqueue[i] << endl;
			}
	}
}

void Queue::Dequeue()
{
	if (isEmpty() )
	{
		cout << "Queue is empty." << endl;
	}
	else if (!isEmpty() )
	{
		int *track = NULL;
		maxsize--;
		int p = front;
		track = new int[maxsize];
		while (p <= rear)
		{
			track[p] = myqueue[p+1];
			p++;
		}

		delete myqueue;
		myqueue = new int[maxsize];

		for (int i = 0; i < maxsize; i++)
		{
			myqueue[i] = track[i];
		}
		delete track;
		rear = maxsize-1;
	}
}

void Queue::Enqueue(int item)
{
	maxsize++;
	int oldsize = maxsize-1;
	int *track = NULL;

	track = new int[oldsize];
	int c = 0;

	while (c <= rear)
	{
		track[c] = myqueue[c];
		c++;
	}
	delete myqueue;
	myqueue = new int[maxsize];
	for (int i = front; i < oldsize; i++)
	{
		myqueue[i] = track[i];
	}
	delete track;
	rear++;
	myqueue[rear] = item;
	
}

bool Queue::isEmpty()
{
	bool check;
	(maxsize == 0 ) ? (check = true) : (check = false);
	return check;
}

bool Queue::isFull()
{
	bool check;
	(rear== (maxsize-1) ) ? (check = true ): (check = false);
	return check;
}

int Queue::getFrontIndex()
{
	return front;
}

int Queue::getRearIndex()
{
	return rear;
}

void Queue::ChangeElement(int index, int element)
{
	if (index <= rear && index >= front)
	{
		myqueue[index] = element;
		return;
	}
	else
	{
		cout << "That index is out of range." << endl;
		return;
	}
}


void ExecuteQueue()
{
	Queue queue;

	queue.PrintQueue();
	queue.Enqueue(2000);
	queue.Enqueue(3000);
	queue.Enqueue(4000);
	queue.Enqueue(7000);
	queue.Dequeue();
	//queue.ChangeElement(queue.getFrontIndex(), 99);
	queue.PrintQueue();
}