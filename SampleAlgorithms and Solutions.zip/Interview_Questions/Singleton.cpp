#include "Singleton.h"
Singleton* Singleton::instance = 0;
int Singleton::numYears = 0;

Singleton::Singleton()
{
	cout << "New presidency." << endl;
	numYears = 4;
	currentPresident = "empty";
	term = 0;
	pastpresident = "empty";
}

int Singleton::getYears()
{
	return numYears;
}

void Singleton::nextPresidency(string President)
{
	pastpresident = currentPresident;
	currentPresident = President;
	if (pastpresident == currentPresident)
	{
		if (term < 2)
		{
			cout << currentPresident << " has another four years." << endl;
			term++;
		}
		else if (term == 2)
		{
			cout << currentPresident << " cannot run for presidency again." << endl;
			currentPresident = "empty";
			pastpresident = currentPresident;
			return;
		}
	}
	else
	{
		cout << currentPresident << " is now the current president." << endl;
		term++;
	}
	numYears = 4;
}

Singleton* Singleton::getInstance()
{
	if (!instance)
		instance = new Singleton();
	return instance;
}

void Singleton::timelength()
{
	if (numYears > 0)
		numYears--;
}

string Singleton::currentP()
{
	return currentPresident;
}

void ExecuteSingleton()
{
	if (Singleton::getYears() == 0)
		cout << "Election time." << endl;

	string president;
	cin >> president;

	Singleton::getInstance()->nextPresidency(president);

	for (int i = 0; i < 4; i++)
		Singleton::getInstance()->timelength();

	if (Singleton::getYears() == 0)
			cout << "4 year term is over." << endl;
	
	char input;
	cout << "Do you want to continue? Y or y to continue: ";
	cin >> input;
	if (input == 'y' || input == 'Y')
	{
		ExecuteSingleton();
	}
	else 
		return;
}