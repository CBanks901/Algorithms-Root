#ifndef _Stack_H_
#define _Stack_H_

#include "Utilities.h"
class StackNode
{
public:
	bool marked;
	int value;
	StackNode()
	{
		marked = false;
		value = 0;
	}

	StackNode(int element, bool marked)
	{
		this->marked = marked;
		value = element;
	}

	~StackNode()
	{
	}

	StackNode& operator=(StackNode& object)
	{
		this->marked = object.marked;
		this->value = object.value;
		return *this;
	}

};

class Stack
{
public:
	Stack(int size);					// default constructor
	Stack(Stack&);				// copy constructor
	~Stack();					// destructor
	int getTop();				// return the top element of the stack
	void push(int element, int level);		// insert a element onto the stack
	void pop();					// remove the top element from the stack
	void clear();				// clear all elements from the stack
	void print(int level);				// print out all the elements in the stack
	bool checkMarked(StackNode&);
	int getStackSize();

private:
	int stacksize;
	StackNode* stack;
	int top;
};

void ExecuteStack();

#endif