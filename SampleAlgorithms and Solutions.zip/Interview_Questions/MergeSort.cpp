#include "MergeSort.h"

#define LESS(x, y ) (x < y) ? true : false
#define EQUAL(x, y) ( x == y ? true : false  )
#define GREATER(x, y) ( (x > y) ? true : false )

MergeSort::MergeSort()
{
}

MergeSort::MergeSort(const MergeSort& copy)
{
}

MergeSort::~MergeSort()
{
}

vector<int> TwobyTwoSort(vector<int> &left, vector<int> &right)
{
	int setAGroup = left.size();
	int setBGroup = right.size();

	cout << "Sorting left side...." << endl;
	switch (setAGroup)
	{
	case 0:
		cout << "No elements to sort." << endl;
		break;
	case 1:
		cout << "Only 1 element. Sort not required." << endl;
		break;
	case 2:
		cout << "Only 2 elements to sort." << endl;
		if (EQUAL(left[0], left[1] ) )
		{
			cout << "List elements are equal.\n" << endl;
		}
		else if (LESS(left[0], left[1] ) )
		{
			cout << "List already sorted.\n" << endl;
		}
		else if (GREATER(left[0], left[1] ) )
		{
			int temp = left[0];
			left[0] = left[1];
			left[1] = temp;
			cout << "Elements sorted on the left.\n" << endl;
		}
		break;
	}

	cout << "Sorting right side....\n" << endl;
	switch (setBGroup)
	{
	case 0:
		cout << "No elements to sort." << endl;
		break;
	case 1:
		cout << "Only 1 element. Sort not required." << endl;
		break;
	case 2:
		cout << "Only 2 elements to sort." << endl;
		if (EQUAL(right[0], right[1] ) )
		{
			cout << "List elements are equal." << endl;
		}
		else if (LESS(right[0], right[1] ) )
		{
			cout << "List already sorted.\n" << endl;
		}
		else if (GREATER(right[0], right[1] ) )
		{
			int temp = right[0];
			right[0] = right[1];
			right[1] = temp;
			cout << "Elements sorted on the right." << endl;
		}
		break;
	}

	if ( left.size() == 2 && right.size() == 2)
	{
		if (GREATER(left[0], right[0]) )
		{
			int temp = left[0];
			left[0] = right[0];
			right[0] = temp;
		}

		if (GREATER(left[0], right[1]) )
		{
			int temp= left[0];
			left[0] = right[1];
			right[1] = temp;
		}

		if (GREATER(left[1], right[0] ) )
		{
			int temp = left[1];
			left[1] = right[0];
			right[0] = temp;
		}

		if (GREATER(left[1], right[1] ) )
		{
			int temp = left[1];
			left[1] = right[1];
			right[1] = temp;
		}

		if (GREATER(right[0], right[1] ) )
		{
			int temp = right[0];
			right[0] = right[1];
			right[1] = temp;
		}

		vector<int>::const_iterator it = left.begin();
		vector<int>::const_iterator it2 = right.begin();
		vector<int> combine(left.size() + right.size() );

		int i(0);
		for (it; it != left.end(); ++it, ++i)
		{
			combine[i] = (*it);
		}

		for (it2; it2 != right.end(); ++it2, ++i)
		{
			combine[i] = (*it2);
		}

		return combine;
	}
}

template <typename T>
void MergeHelper(T *&arrayvalue, vector<T> vec)
{
	// copy the vector values into the array
	for (int j = 0; j <= vec.size()-1; ++j)
	{
		arrayvalue[j] = vec[j];
	}

	// Sorts the current list
	for (int p = 0; p <=vec.size()-1; ++p)
	{
		for (int l = vec.size()-1; l != p; l--)
		{
			cout << "P: " << p << "\tL: " << l << endl;
			if ( GREATER(arrayvalue[p], arrayvalue[l] ) )
			{
				T temp = arrayvalue[p];
				arrayvalue[p] = arrayvalue[l];
				arrayvalue[l] = temp;
			}
		}
	}

	cout << "Half sorted..." << endl;
	for (int r = 0; r < vec.size(); r++)
		cout << arrayvalue[r] << endl; 
}

vector<int> MergeSort::Mergesort(vector<int> &left, vector<int> &right)
{
	vector<int> copy1;

	// beginning of left side sort
	int *arraycopies = new int[left.size()];
	MergeHelper(arraycopies, left);
	// end of left side sort

	// Right side sort
	int *arraycopies2 = new int[right.size()];
	MergeHelper(arraycopies2, right);
	// end of right sort

	vector<int> LeftV, RightV;

	// simply goes through each vectors values for the LeftV and RightV values
	int Left(0), Right(0);

	while (Left <= left.size()-1 )
	{
		LeftV.push_back(arraycopies[Left++]);
	}

	while (Right <= right.size()-1 )
	{
		RightV.push_back(arraycopies2[Right++]);
	}

	delete [] arraycopies;
	delete [] arraycopies2;

	// values used when comparing 
	while (!LeftV.empty() && !RightV.empty() )
	{
		if (EQUAL(LeftV[0], RightV[0]) )
		{
			// since the elements are equal push them both into the vector
			copy1.push_back(LeftV[0]);
			copy1.push_back(RightV[0]);

			// and then remove them from the original vectors
			LeftV.erase(LeftV.begin());
			RightV.erase(RightV.begin());
		}
		// if the left elements vector is less than the right elements vector
		else if (LESS(LeftV[0], RightV[0]) )
		{
				copy1.push_back(LeftV[0]);	// add this left element to the combined vector
				// erase the value
				LeftV.erase(LeftV.begin());
		}
		// if left value is greater than the right
		else if (GREATER(LeftV[0], RightV[0]) )
		{
			// add the right vector value to the combine vector
			copy1.push_back(RightV[0]);
			RightV.erase(RightV.begin());
		}
	}

	if (LeftV.empty() && !RightV.empty() )
	{
		while (!RightV.empty() )
		{
			copy1.push_back(RightV[0]);
			RightV.erase(RightV.begin());
		}
	}

	else if (!LeftV.empty() && RightV.empty() )
	{
		while (!LeftV.empty() )
		{
			copy1.push_back(LeftV[0]);
			LeftV.erase(LeftV.begin());
		}
	}
	
	vector<int>::const_iterator it = copy1.begin();

	cout << "Complete list sorted." << endl;
	for (it; it != copy1.end(); ++it)
	{
		cout << (*it) << endl; 
	}

	return copy1;
}

vector<char> MergeSort::Mergersort(vector<char> &left, vector<char> &right)
{
	char *leftstring = new char[left.size()];
	MergeHelper(leftstring, left);
	char *rightstring = new char[right.size()];
	MergeHelper(rightstring, right);

	int leftsize(0), rightsize(0);

	vector<char> copy;
	vector<char> leftduplicate;
	vector<char> rightduplicate;

	while (leftsize <= left.size()-1 )
	{
		leftduplicate.push_back(leftstring[leftsize++]);
	}

	while (rightsize <= right.size()-1)
	{
		rightduplicate.push_back(rightstring[rightsize++]);
	}

	delete [] leftstring;
	delete [] rightstring;

	while (!leftduplicate.empty() && !rightduplicate.empty() )
	{
		if (EQUAL(leftduplicate[0], rightduplicate[0] ) )
		{
			copy.push_back(leftduplicate[0] );
			copy.push_back(rightduplicate[0] );

			leftduplicate.erase(leftduplicate.begin() );
			rightduplicate.erase(rightduplicate.begin() );
		}
		
		else if (LESS(leftduplicate[0], rightduplicate[0]) )
		{
			copy.push_back(leftduplicate[0]);
			leftduplicate.erase(leftduplicate.begin() );
		}

		else if (GREATER(leftduplicate[0], rightduplicate[0]) )
		{
			copy.push_back(rightduplicate[0]);
			rightduplicate.erase(rightduplicate.begin());
		}
	}

	if (leftduplicate.empty() && !rightduplicate.empty() )
	{
		while (!rightduplicate.empty() )
		{
			copy.push_back(rightduplicate[0]);
			rightduplicate.erase(rightduplicate.begin() );
		}
	}

	else if (!leftduplicate.empty() && rightduplicate.empty() )
	{
		while (!leftduplicate.empty() )
		{
			copy.push_back(leftduplicate[0]);
			leftduplicate.erase(leftduplicate.begin() );
		}
	}

	vector<char>::const_iterator it = copy.begin();

	cout << "Complete list." << endl;
	for (it; it != copy.end(); ++it)
	{
		cout << (*it) << endl;
	}
	return copy;
}

void MergeSort::Merge(vector<int> &left, vector<int> &right, int pivot, int pivotL, int pivotR)
{
}

// Helper function
void SetValue(vector<int>::iterator &it, int i)
{
	(*it) = i;
	++it;
}

void ExecuteMergeSort()
{
	cout << "Do you want to choose the number of elements to insert? 1 for yes, 0 for no: " ;
	int input(0);
	cin >> input;
	vector<int> vect;
	while (input < 0 || input > 1)
	{
		cout << "Please enter a proper value: \a";
		cin >> input;
	}

	if (input == 0)
	{
		vect = vector<int>(12);
		vector<int>::iterator it = vect.begin();

		SetValue(it, 2);
		SetValue(it, 4);
		SetValue(it, 5);
		SetValue(it, 9);
		SetValue(it, 10);
		SetValue(it, 11);

		SetValue(it, 8);
		SetValue(it, 6);
		SetValue(it, 1);
		SetValue(it, 7);
		SetValue(it, 3);
		SetValue(it, 14);
	}
	else if (input == 1)
	{
		int numelements(0);
		cout << "Please choose the number of elements: ";
		cin >> numelements;
		
		while (numelements <= 1)
		{
			cout << "\aError. Please choose a value higher than 0 and 1." << endl;
			cin >> numelements;
		}

		vect = vector<int>(numelements);
		int counter(0);
		vector<int>::iterator it = vect.begin();

		cout << "\aDo you want to generate random output? 1 for yes and 0 for no: ";
		int random(0);
		cin >> random;

		while (random < 0 || random > 1)
		{
			cout << "\aNot a applicable choice. Try again: " << endl;
			cin >> random;
		}
		while (counter < numelements)
		{
			static int value;
			cout << counter << ": ";
			if (random == 0)
				cin >> value;
			else if (random == 1)
			{
				value = rand() % numelements+1;
				cout << value << endl;
			}
			SetValue(it, value);
			counter++;
		}
	}

	int pivot(0);
	if (vect.capacity() % 2 == 0)
		pivot = vect.capacity() / 2;
	else if (vect.capacity() % 2 == 1)
		pivot = vect.capacity()/2 +1;

	vector<int> copy, copy2;
	
	copy.assign(vect.begin(), vect.begin()+pivot);
	copy2.assign(vect.begin()+pivot, vect.end() );

	vector<int>::const_iterator it2 = copy.begin();
	int l = 0;
	cout << "First list: \a" << endl;
	for (it2, l; it2 != copy.end(); ++l, ++it2)
	{
		cout << copy[l] << endl;
	}
	
	it2 = copy2.begin();
	cout << "Second list: \a" << endl;
	for (it2, l = 0; it2 != copy2.end(); ++l, ++it2)
	{
		cout << copy2[l] << endl;
	}

	MergeSort sort;
	vector<int> combined;
	combined = sort.Mergesort(copy, copy2);
}

void ExecuteCharMergerSort()
{
	vector<char> values;

	values.push_back('s');
	values.push_back('t');
	values.push_back('u');
	values.push_back('b');
	values.push_back('b');
	values.push_back('o');
	values.push_back('r');
	values.push_back('n');

	int pivot(0);
	if (values.size() % 2 == 0)
		pivot = values.size()/2;
	else if (values.size() % 2 == 1)
		pivot = values.size()/2 + 1;

	vector<char> left, right;

	left.assign(values.begin(), values.begin()+pivot);
	right.assign(values.begin()+pivot, values.end() );
	
	MergeSort mysort;
	mysort.Mergersort(left, right);
}