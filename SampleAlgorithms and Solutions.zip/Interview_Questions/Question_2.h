#include "Utilities.h"

// my example
void reverseS(char* str)
{
	int i = 0;	
	// loop through until we get to the null character
	while (str[i] != '\0')
	{
		i++;		// increment this value for later
	}
	char *copy = new char[i];		// create a copy character array based on the i value count
	const int c = i;			   // maximum value
	for (int q = 0; q <= c; q++)
	{
		copy[q] = str[i];			// set the first value of copy to the last value of the string
		i--;						// decremnet i to keep going down
	}
	int fi = 0;						// copy variable just like before
	// loop to start at the end of the word until we hit the beginnign
	for (int l = c; l >= 0; l--)
	{
		str[l] = copy[fi];			// set the last value of string to the first value of copy
		cout << str[l] << endl;
		fi++;						// increment this so that copy continues looping forward
	}
	return;
}

