#include "Stack.h"

Stack::Stack(int size)
{
	stacksize = 0;
	stack = new StackNode[size];
	top = 0;
	
	for (int i = 0; i < size; i++)
	{
		stack[i].marked = false;
		stack[i].value = 0;

		cout << "Stack[" << i << "] value =\t" << stack[i].value << endl;
	}
}

Stack::~Stack()
{
}

void Stack::pop()
{
	stack[stacksize].marked = false;
	stack[stacksize].value = 0;

	stacksize--;
	top = stack[stacksize-1].value;

}

void Stack::push(int element, int level)
{
	if (stacksize == 0)
	{
		stack[stacksize].marked = true;
		stack[stacksize].value = element;
		top = stack[stacksize].value;
	}

	else
	{
		if (level != stacksize)
			return push(element, level+1);

		if (level == stacksize)
		{
			bool value = checkMarked(stack[level]);

			if (value)
			{
				cout << "Node has already been marked.\n";

				cout << "Do you want to add a new node?\n";

				cout << "Y or N? \n: ";

				char input;
				cin >> input;

				if (islower(input) )
				{
					input = toupper(input);
				}

				if (input == 'Y')
				{
					StackNode *copy = stack;
					stack = new StackNode[stacksize+1];
					stack = copy;
					stacksize++;
					stack[stacksize-1] = StackNode(element, true);
					top = stack[stacksize-1].value;
					return;
				}
				else if (input == 'N')
				{
					return;
				}

				else
				{
					cout << "Sorry. Please enter Y or N to continue.\n";
					return push(element, level);
				}
			}
			else if (!value)
			{
				stack[level].marked = true;
				stack[level].value = element;
				top = stack[level].value;		// set the newly added element as the top
			}
		}
	}
	stacksize++;
}

int Stack::getTop()
{
	return top;
}

void Stack::clear()
{
	while (stacksize != 0)
	{
		if (stacksize == 0)
		{
			cout << "Stack reinitialized.\n";
		}

		else
		{
			stack[stacksize].value = 0;
			stack[stacksize].marked = false;

			stacksize--;
			if (stacksize == 0)
				top = 0;
			else
				top = stack[stacksize-1].value;			// remember to reset the top
		}
	}
}

void Stack::print(int level)
{
	while (level >= 0)
	{
		cout << "Level: " << level << "\t Value: " << stack[level].value << endl;
		return print(level-1);
	}

	cout << "Top: " << getTop() << endl;
	cout << "Stack size: " << getStackSize() << endl;
}

bool Stack::checkMarked(StackNode& node)
{
	return node.marked;
}

int Stack::getStackSize()
{
	return stacksize;
}

void ExecuteStack()
{
	Stack mystack(5);

	mystack.push(15, 0);
	mystack.push(3, 0);
	mystack.push(10, 0);
	mystack.push(11, 0);
	mystack.push(13, 0);
	mystack.push(17, 0);
	mystack.push(22, 0);
	
	mystack.print(mystack.getStackSize() -1 );
	mystack.pop();
	mystack.print(mystack.getStackSize()-1);
}