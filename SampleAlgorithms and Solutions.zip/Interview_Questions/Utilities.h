// NOTE: Include this in every header file
#include <string>
#include <sstream>
#include <iostream>
#include <conio.h>
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys\types.h>
#include <time.h>
#include <vector>

using namespace std;