#include "Utilities.h"

class Remote;

class TV
{
public:
	TV() : channel(0) , volume(0), brightness(40)
	{
		previous[0] = previous[1] = previous[2] = 0;
	}
	void printcurrentChannel()
	{
		cout << "Current Channel: " << channel << endl;
		cout << "Previous Channel: " << previous[0] << endl;
	}
	void printCurrentVolume()
	{
		cout << "Current Volume: " << volume << endl;
		cout << "Previous Volume: " << previous[1] << endl;
	}
	void printCurrentBrightness()
	{
		cout << "Current Brightness: " << brightness << endl;
		cout << "Previous Brightness: " << previous[2] << endl;
	}
private:
	void setChannel(int chan)
	{
		previous[0] = channel;
		channel = chan;
	}
	void setVolume(int volume)
	{
		previous[1] = (*this).volume;
		this->volume = volume;
	}
	void setBrightness(int bright)
	{
		previous[2] = brightness;
		brightness = bright;
	}
	friend class Remote;

private:
	// previous 0 is the channel, 1 is volume, and 2 is brightness
	int channel, volume, brightness, previous[3];
};

class Remote
{
public:
	void changeChannel(TV &object, int newChannel)
	{
		if (newChannel == object.channel)
			cout << "Please specifiy a different channel.\n";
		else
			object.setChannel(newChannel);
	}

	void changeVolume(TV &object, int volume)
	{
		if (volume == object.volume)
			cout << "Volume already set. Please choose a different volume\n" ;
		else
			object.setVolume(volume);
	}

	void changeBrightnesss(TV &object, int bright)
	{
		if (bright == object.brightness)
			cout << "Please choose a different brightness.\n";
		else
			object.setBrightness(bright);
	}
};

void ExecuteExample()
{
	TV newTV;
	Remote newTVRemote;
	Remote* myRemote = new Remote();
	
	string value1, value2, value3;
	int volume, channel, brightness;
	cout << "\aPlease enter a new volume: ";
	getline(cin, value1);

	stringstream(value1) >> volume;
	myRemote->changeVolume(newTV, volume);

	cout << "\aPlease enter a new channel now: ";
	getline(cin, value2);

	stringstream(value2) >> channel;
	myRemote->changeChannel(newTV, channel);

	cout << "Finally please enter the brightness now:\a ";
	getline(cin, value3);

	stringstream(value3) >> brightness;
	(*myRemote).changeBrightnesss(newTV, brightness);
	
	newTV.printCurrentVolume();
	newTV.printcurrentChannel();
	newTV.printCurrentBrightness();

	delete myRemote;
	cout << "\aRepeat? Y for Yes, N for No: ";
	char input;
	cin >> input;
	(input == 'Y' || input == 'y') ? ExecuteExample() : cout << "Terminating function.\n";
}