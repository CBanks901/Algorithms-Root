#ifndef _BinaryTree_H_
#define _BinaryTree_H_
#include "Utilities.h"

struct TreeNode
{
	TreeNode *left, *right;
	bool leaf;
	int data;
	int level;
	char traversal;
	TreeNode *parent;				// points back to its parent

	TreeNode()
	{
		data = 0;
		leaf = true;
		left = NULL;
		right = NULL;
	}
	TreeNode(int data)
	{
		(*this).data = data;
		leaf = true;
		left = NULL;	// make sure to rest these
		right = NULL;	// to NULL
	}
	~TreeNode()
	{

	}
};

// when a node has two children use this structure to hold both children's values (left and right)
struct NodePack
{
	TreeNode* left;
	TreeNode* right;
};

class BinaryTree
{
public:
	BinaryTree();
	~BinaryTree();
	TreeNode* getRoot();				// returns a pointer to the root node
	TreeNode* findLeaf(TreeNode* node);
	void repairTree(TreeNode*& node);
	bool isleafNode(TreeNode* node);		// determines if the node is a leaf	
	NodePack oneChildNode(TreeNode* node);
	NodePack twoChildNode(TreeNode* node);
	void InsertRootNode(int data);
	void InsertNode(int data);
	void RemoveNode(int data);
	void printTree();					// just basic for now
	int getNodeValue(TreeNode* node);
	int Count();
	void printParents(TreeNode* node);
	void printTraversal(TreeNode* node);
	TreeNode* SearchTree(int data);

private:
	void Insert(TreeNode*& node, int data, TreeNode*previous, char traverse);
	void Remove(TreeNode*& node, int data);
	TreeNode* Search(TreeNode* node, int data);
	TreeNode* root;
	int count;
};

void ExecuteBinaryTree();
int Compare(int x, int y);		// returns 0, 1, or 2 (0): Less than (1): Equal to (2): Greater than
// NOTE: Always set y to the node in question. Example: is 7 greater than 5(root node)
#endif