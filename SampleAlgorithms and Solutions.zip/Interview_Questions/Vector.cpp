#include "Vector.h"

FavoriteConsoles::FavoriteConsoles()
{
	console.reserve(5);
	vector<string>::const_iterator it = console.begin();

}

FavoriteConsoles::FavoriteConsoles(string*values, int size)
{
	for (int p = 0; p < size; ++p)
	{
		console.push_back(values[p]);
	}
}

FavoriteConsoles::FavoriteConsoles(vector<string> values, int size)
{
	for (int p = 0; p < size; ++p)
	{
		console.push_back(values[p]);
	}
}

FavoriteConsoles::~FavoriteConsoles()
{
	console.clear();
}

bool FavoriteConsoles::checkIterator(vector<string>::const_iterator it)
{
	bool checker;
	(*it != "\0") ? (checker = true) : (checker = false);
	return checker;
}

string FavoriteConsoles::getValue(int i)
{
	if (i > console.size() || i < 0)
	{
		cout << "That value is out of range." << endl;
		return "empty";
	}

	vector<string>::const_iterator it = (console.begin() + i)-1;
	if (checkIterator(it))
		return (*it);
	else 
		return "empty";
}

int FavoriteConsoles::getIndex(string v)
{
	vector<string>::const_iterator it = console.begin();
	int i = 0;
	while ((*it) != v )
	{
		++i;
		if (it != console.end()-1 )
			++it;
		else
		{
			cout << v << " not found." << endl;
			break;
		}
	}

	if ( (*it) == v)
	{
		cout << "Value found." << endl;
		return i;
	}
	else
		return 0;
}

void FavoriteConsoles::PrintFavorites()
{
	vector<string>::const_iterator it = console.begin();
	cout << "Your favorite consoles in the following order are: " << endl;
	int counter = 1;

	for (it, counter; it != console.end(); ++it, ++counter)
	{
		cout << (*it) << " with the spot of: " << counter << endl;
	}
}

void ExecuteVector()
{
	cout << "How many consoles do you have? ";
	int consoles = 0;
	cin >> consoles;


	vector<string> mystring;
	int i = 0;
	cout << "Please enter your favorite consoles below." << endl;
	string copy;
	
	for (i; i < consoles; ++i)
	{
		copy = "\0";
		cin >> copy;
		mystring.push_back(copy);
		cout << "\a";
	}

	FavoriteConsoles games(mystring, consoles);
	games.PrintFavorites();

	cout << "\aRepeat? Y or N" << endl;
	char input;
	cin >> input;

	if (input == 'Y')
		ExecuteVector();
	else if (input == 'N')
		return;
	else
	{
		cout << "\aInput invalid. Please enter Y or N: ";

		cin >> input;
		if (input == 'Y')
			ExecuteVector();
		if (input == 'N')
			return;
		while (input != 'Y' || input != 'N')
		{
			cout << "\aTry again: ";
			cin >> input;
			if (input == 'Y')
				break;
			else if (input == 'N')
				break;
		}

		if (input == 'Y')
			ExecuteVector();
		else if (input == 'N')
			return;
	}
}