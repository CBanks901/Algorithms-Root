#ifndef Singleton_H_
#define Singleton_H_
#include "Utilities.h"

/* 
Date: August 27th, 2015
Purpose: this program uses the presidency as a singleton example
Notes: after a four year term a new president is chosen
Status: incomplete 
*/

class Singleton
{
public:
	static Singleton* getInstance();
	static int getYears();
	void nextPresidency(string President);
	string currentP();
	void timelength();
protected:
	Singleton();
private:
	static int numYears;
	static Singleton* instance;
	int term;
	string currentPresident;
	string pastpresident;
};

void ExecuteSingleton();
#endif