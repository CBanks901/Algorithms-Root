#ifndef _HashTable_H_
#define _HashTable_H_
#include "Utilities.h"

class HashData
{
public:
	string value;
	int key;

	int getkey()
	{
		return key;
	}

	string getValue()
	{
		return value;
	}
};

class HashTable
{
public:
	HashTable();
	HashTable(int size);
	~HashTable();
	void Hash(int key, string value);
	int getTableSize();
	int getItem(int key);


private:
	int tablesize;
	HashData **entry;
};

void ExecuteHash();

// Another example of hashtable implementation
/*
struct DataType
{
	int id;
	string value;

	DataType()
	{
		value = "empty";
		id = NULL;
	}

	DataType(string value, int id)
	{
		(*this).value = value;
		(*this).id = id;
	}

	~DataType()
	{
	}
};

class SampleTable
{
public:
	SampleTable()
	{
		TableSize = 5;

		table = NULL;

		table = new DataType*[TableSize];

		for (int i = 0; i < TableSize; i++)
			table[i] = new DataType();
	}

	SampleTable(string elements[], int arraysize, int id[])
	{
		TableSize = arraysize;

		table = new DataType*[arraysize];
		for (int i = 0; i < arraysize; i++)
		{
			table[i] = new DataType(elements[i], id[i]);
		}
	}

	~SampleTable()
	{
		for (int i = 0; i < TableSize; i++)
			delete table[i];
	}

	void PrintValues()
	{
		int i = 0;
		while (i < TableSize)
		{
			cout << table[i]->value << " " << table[i]->id << endl;
			i++;
		}
	}

	int getSize()
	{
		return TableSize;
	}

	int hashData(string value, int employeeNumber)
	{
		hash = 0;

		if (hash < TableSize)
		{
			while (table[hash]->id != NULL && table[hash]->id != employeeNumber)
			{
				hash = hash % TableSize + 1;

				 if (hash >= TableSize)
				 {
					TableSize++;
					table[hash] = new DataType(value, employeeNumber);
					return hash;
				 }
			}
		}

		if (table[hash]->id != NULL)
		{
			if (table[hash]->id == employeeNumber)
			{
				if (table[hash]->value == value)
				{
					cout << "Repeat." << endl;
					return 0;
				}
				else
				{
					hash = hash + 1;

					if (hash > TableSize)
						TableSize = hash;

					int nextid = 0;
					if (table[hash+1])
						nextid = table[hash+1]->id;
					int currentid;
					if (nextid == employeeNumber)
						currentid = rand();
					else 
						currentid = employeeNumber + 1;

					table[hash] = new DataType(value, currentid);
					return hash;
				}
			}
			return hash;
		}
		else if (table[hash]->id == NULL)
		{
			table[hash] = new DataType(value, employeeNumber);
		}
		return hash;
	}

	int Search(int key)
	{
		hash = 0;

		while (table[hash]->id != key)
		{
			hash = hash % TableSize + 1;
			if (hash == TableSize - 1)
				break;
		}

		if (table[hash]->id == key)
		{
			cout << "Value at key " << key << ": " << table[hash]->value << endl;
			return table[hash]->id;
		}
		else
		{
			cout << "Either that key doesn't exist or item not found." << endl;
			return 0;
		}
	}

	string Search(string value)
	{
		hash = 0;
		
		while (table[hash]->value != value)
		{
			hash = hash % TableSize + 1;

			if (hash == TableSize-1)
				break;
		}

		if (table[hash]->value == value)
		{
			cout << "Key " << table[hash]->id << " found at string: " << table[hash]->value << endl;
			return table[hash]->value;
		}
		else
		{
			cout << "String " << value << " does not exist." << endl;
			return string();
		}
	}

	int hash;
	int id;
	string value;
private:
	DataType **table;
	int TableSize;
};

string elements[] = {"Naruto", "Sasuke", "Sakura", "Kakashi", "Gaara", "Itachi" };
	int id[] = {1, 2, 3, 4, 5, 6};
	SampleTable table(elements, 6, id);
	
	table.PrintValues();
	table.Search("Itachi");
*/
#endif