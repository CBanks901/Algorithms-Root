#include "LinkedList.h"


LinkedList::LinkedList()
{
	head = NULL;
	tail = NULL;
	size = 0;
}

LinkedList::~LinkedList()
{
	while (head != NULL)
	{
		head = head->next;
		delete head;
	}

	while (tail != NULL)
	{
		tail = tail->next;
		delete tail;
	}
}

LinkedList::LinkedList(LinkedList& list)
{
	head = tail = NULL;
	size = 0;

	Node* current = list.head;

	// Rememeber to loop through all elements here
	while (current != NULL)
	{
		addLast(current->element);		// add them in order, no additional sorting needed
		current = current->next;		// as always go to the next element in the list
	}	
}

void LinkedList::addFirst(int element)
{
	if (head == NULL)
	{
		Node *current = head;
		current = new Node(element);
		head = current;
		tail = current;
	}
	else
	{
		Node *current = head;
		current = new Node(element);
		current->next = head;
		head = current;		// Remember to reset the head value each time
	}
	size++;
}

void LinkedList::addLast(int element)
{
	Node* current = head;

	if (head == NULL)
	{
		addFirst(element);
		return;
	}

	else
	{
		// subtract 1 from the loop here 
		for (int i = 0; i < size-1; i++)
		{
			current = current->next;
		}
		 current->next = new Node(element);
		 tail = current->next;
	}

	size++;
}

void LinkedList::add(int element, int index)
{
	Node* current = head;
	if (index <= 0)
	{
		addFirst(element);
		return;
	}
	else if (index >= size)
	{
		addLast(element);
		return;
	}
	else
	{

		for (int i = 0; i < index-1; i++)
		{
			current = current->next;
		}

		// Remember this area
		// save the next node after the current one which will be removed
		Node* temp = current->next;

		current->next = new Node(element);			// create a new element following the node to be inserted
		current->next->next = temp;					// set the node after the created node to the node that was deleted

		size++;

	}
}

void LinkedList::removeLast()
{
	Node* current = head;

	if (size == 0)
	{
		cout << "No elements to remove." << endl;
		return;
	}

	else if (size == 1)
	{
		cout << "Removed element: " << current->element << endl;
		current = tail = NULL;
		delete current;
	}

	else
	{
		while (current != NULL)
		{
			if (current->next)
				if (current->next == tail)
				{
					tail = current;
					current->next = NULL;		// remember to reset the following node to 0
					break;						// and to terminate this while statement if here
				}
			current = current->next;
		}
	
	}
	size--;
}

void LinkedList::removeFirst()
{
	Node* current = head;

	if (size == 0)
	{
		cout << "Unable to remove any elements from this list." << endl;
		return;
	}
	else if (size == 1)
	{
		cout << "List size 1. Element: " << current->element << "\tremoved.\n";
		current = tail = NULL;
		delete current;
	}

	else
	{
		Node* temp = head;
		cout << "Removed element: " << current->element << endl;
		current = NULL;
		delete current;

		head = temp->next;
		cout << "New head: " << head->element << endl;
	}
	size--;
}

void LinkedList::removeI(int index)
{
	Node* current = head;

	if (index == 0)
	{
		removeFirst();
		return;
	}
	// make sure that this isn't >= to the size
	else if (index > size)
	{
		cout << "Index is too high.\n";
		return;
	}
	else if (index <= size)
	{
		for (int v = 1; v < index; v++)
			current = current->next;
	
		removeE(current->element);		// call removeE to do most of the work for us
	}
}

void LinkedList::removeE(int element)
{
	bool check = checkElement(element);

	if (!check)
	{
		return;
	}

	else if (check)
	{
		if (getindex(element) == 0)
		{
			removeFirst();
		}

		else 
		{
			Node* current = head;

			// create a temp pointer that holds the old location from the previous node. In the beginning
			// it is the same as current
			Node* previous = current;		// Remember this code line
			while (current->element != element)
			{
				// Previous will always equal the node before the current one
				previous = current;			// and this. 
				current = current->next;
			}

			// Remember this area
			if (current == tail)
			{
				removeLast();
			}
			else
			{
				current->element = 0;
				current = NULL;
				delete current;

				previous->next = previous->next->next;
				size--;
			}
		}
	}
}

bool LinkedList::checkElement(int element)
{
	Node* current = head;

	for (int i = 0; i < size; i++)
	{
		if (current->element == element)
		{
			cout << "Match found!\n";
			return true;
		}
		else 
			current = current->next;
	}

	cout << "Element doesn't exist.\n";
	return false;
}

int LinkedList::getsize()
{
	return size;
}

int LinkedList::getindex(int element)
{
	Node* current = head;
	for (int i = 0; i < size; i++)
	{
		if (current->element == element)
			return i;
		else
			current = current->next;
	}

	cout << "\aElement does not exist.\n";
	return -1;
}

void LinkedList::printList()
{
	cout << "List size: " << size << endl;

	Node* temp = head;
	for (int i = 0; i < size; i++)
	{
		cout << "Index: " << getindex(temp->element) << "\t Value: " << temp->element << endl;
		temp = temp->next;
	}
		cout << "Tail: " << tail->element << endl;
}