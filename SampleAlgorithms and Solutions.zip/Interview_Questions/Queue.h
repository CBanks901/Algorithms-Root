#ifndef Queue_H_
#define Queue_H_

#include "Utilities.h"

class Queue
{
public:
	Queue();
	Queue(int size);
	~Queue();

	int getSize();
	int getRear();
	int getFront();

	void Enqueue(int item);
	void Dequeue();		// only the last element for now
	void initalize();
	void clear();
	void PrintQueue();
	bool isEmpty();
	bool isFull();
	void ChangeElement(int index, int element);
	int getRearIndex();
	int getFrontIndex();

private:
	int rear, front;
	int maxsize;
	int *myqueue;
};

void ExecuteQueue();
#endif