#include "BinaryTree.h"

#define LESS_THAN(x, y) ( (x) < (y) ? (x): (y) ) 
#define GREATER_THAN(x, y) ( (x) > (y) ? (x): (y) )
#define EQUAL_TO(x, y) ( (x) == (y) )

BinaryTree::BinaryTree()
{
	root = NULL;
	count = 0;
}

BinaryTree::~BinaryTree()
{
	count = 0;
	delete root;
}

TreeNode* BinaryTree::getRoot() 
{
	return root;
}

void BinaryTree::InsertRootNode(int data)
{
	root = new TreeNode(data);
	count++;
}

void BinaryTree::InsertNode(int data)
{
	Insert(root, data, NULL, NULL);
}

void BinaryTree::RemoveNode(int data)
{
	TreeNode* copy = SearchTree(data);
	if (copy == NULL)
		cout << "Failed to remove node." << endl;
	else 
	{
		if (root->data != data)
		{
			if (isleafNode(copy) )
			{
				TreeNode* reset = copy;
				reset = reset->parent;
				reset->leaf = true;			// set this as a leaf now

				cout << "Removing leaf node: " << copy->data << endl;
				delete copy;
				count--;
			}
			// has only one child
			else if ( (copy->left == NULL && copy->right != NULL) || (copy->left != NULL && copy->right == NULL) )
			{
				
				TreeNode* leaf = copy;
				leaf = findLeaf(leaf);

				TreeNode* reset = leaf;
				reset = reset->parent;

				if (!isleafNode(reset) && (reset->left != NULL && reset->right == NULL) || (
					reset->left == NULL && reset->right != NULL ) )
					reset->leaf = true;
				else if (reset->left != NULL && reset->right != NULL)
					reset->leaf = false;

				cout << "Removing 1 child node: " << copy->data << endl;
				copy->data = leaf->data;
				delete leaf;
				repairTree(copy);
				count--;
			}

			// has two chidren
			else if ( (copy->left != NULL && copy->right != NULL) )
			{
				TreeNode* leaf = findLeaf(copy);

				TreeNode* reset = leaf;
				reset = reset->parent;
				reset->leaf = true;			// set this as a leaf now

				cout << "Removing 2 child node: " << copy->data << endl;
				copy->data = leaf->data;
				delete leaf;
				cout << "Swapped with leaf node: " << copy->data << endl;

				repairTree(copy);
				count--;

			}
		}
		else 
			cout << "Root cannot be removed." << endl;
	}
}


void BinaryTree::repairTree(TreeNode*& node)
{
	if (node->left != NULL)
	{
			int i = Compare(node->data, node->left->data);
		
			if (i == 1)
			{
				int temp = node->data;
				node->data = node->left->data;
				node->left->data = temp;
				return repairTree(node->left);
			}
			else 
				return;

	}
	// Undone
	else if (node->left == NULL && node->right != NULL)
	{
		int i = Compare(node->data, node->right->data);

			if (i == 2)
			{
				int temp = node->data;
				node->data = node->right->data;
				node->right->data = temp;
				return repairTree(node->right);
			}

			else 
				return;
	}
}

TreeNode* BinaryTree::SearchTree(int data)
{
	TreeNode* node = root;
	int i = Compare(data, node->data);

	if ( i == 0)
	{
		cout << "Root node located: " << node->data << endl;
		return node;
	}
	else if (i == 1)		// keep our search on the left side
	{
		if (!isleafNode(node) )
		{
			if (node->left != NULL)
			{
				node = node->left;			// it must be on the left side of the tree
				return Search(node, data);
			}
			else 
				cout << "Node " << data << " doesn't exist." << endl;
		}
		else
		{
			cout << "Node " << data << " doesn't exist." << endl;
			return NULL;
		}
	}

	else if (i == 2)
	{
		if (!isleafNode(node) )
		{
			if (node->right != NULL)
			{
				node = node->right;
				return Search(node, data);
			}
			else 
				cout << "Node " << data << " doesn't exist." << endl;
		}
		else
		{
			cout << "Node " << data << " doesn't exist." << endl;
			return NULL;
		}
	}

	else 
	{
		cout << "Node " << data << " is not in the tree." << endl;
		return NULL;
	}

}

void Preorder(TreeNode* node)
{
	if (node == NULL)
		return;

	cout << node->data << endl;
	Preorder(node->left);
	Preorder(node->right);
}

void Inorder(TreeNode* node)
{
	if (node == NULL)
		return;

	Inorder(node->left);
	cout << node->data << endl;
	Inorder(node->right);
}

void PostOrder(TreeNode* node)
{
	if (node == NULL)
		return;

	PostOrder(node->left);
	PostOrder(node->right);
	cout << node->data << endl;
}

void BinaryTree::printTree()
{
	cout << "Which Traversal would you like to see?"
		<< "\nPreorder (p), Inorder(i) or PostOrder(o)" << endl;
	char input;
	input = _getch();
	cout << input;
	if (input != 'p' && input != 'i' && input != 'o')
	{
		while (input != 'p' && input != 'i' && input != 'o' )
		{
			cout << "\a\nError. Try again, p, i or o: ";
			input = _getch();
			cout << input;
		}
	} 
	cout << "\n" << endl;
	switch (input)
	{
	case 'p':
		Preorder(root);
		break;
	case 'i':
		Inorder(root);
		break;
	case 'o':
		PostOrder(root);
		break;
	default:
		cout << "Preorder called by default." << endl;
		Preorder(root);
		break;
	}

	cout << "Repeat print? Y or N : ";
	input = _getch();
	cout << input;
	if (input != 'Y' && input != 'N')
	{
		while (input != 'Y' && input != 'N')
		{
			cout << "\a\nTry again please: ";
			input = _getch();
			cout << input;
		}
	}

	if (input == 'Y')
	{
		cout << endl;
		printTree();
	}
	else if (input == 'N')
	{
		cout << "\n";
		return;
	}
}

void BinaryTree::printTraversal(TreeNode* node)
{
	/*cout << "Backwards ordering." << endl;
	while (node->data != getRoot()->data)
	{
		cout << node->traversal << endl;
		node = node->parent;
	}*/

	cout << "Forward ordering." << endl;
	int i;
	TreeNode* copy = root;
	while (copy->data != node->data)
	{
		i = Compare(node->data, copy->data);
		if (i == 1)
			copy = copy->left;
		else if (i == 2)
			copy = copy->right;
		cout << copy->traversal << endl;
	}
}

void BinaryTree::printParents(TreeNode* node)
{
	if (node == NULL)
	{
		cout << "Node is invalid." << endl; 
		return;
	}
	while (node->data != getRoot()->data)
	{
		if (node->parent->data == getRoot()->data)
			cout << node->data << "'s Parent: " << node->parent->data << "(Root)" << endl;
		else
			cout << node->data << "'s Parent: " << node->parent->data << endl;
		node = node->parent;
	}
}

TreeNode* BinaryTree::findLeaf(TreeNode* node)
{
	if (node == NULL)
		return &TreeNode();

	while (!isleafNode(node) )
	{
			if (node->left != NULL)
				node = node->left;
			else if (node->left == NULL && node->right != NULL)
					node = node->right;
	}

	return node;
}

int BinaryTree::getNodeValue(TreeNode* node)
{
	return node->data;
}

bool BinaryTree::isleafNode(TreeNode* node)
{
	if (node == NULL)
		return false;

	if (node->leaf)
	{
		cout << "Node: " << node->data << " is a leaf node." << endl;
		return true;
	}
	else if (!node->leaf)
	{
		cout << "Node: " << node->data << " is not a leaf node." << endl;
		return false;
	}
	
}

int BinaryTree::Count()
{
	return count;
}

void BinaryTree::Insert(TreeNode*& node, int data, TreeNode*previous, char traverse)
{
	
	if (node == NULL || node->data == 0)
	{
		node = new TreeNode(data);
		node->traversal = traverse;
		node->parent = previous;
		count++;
	}

	else if (node != NULL)
	{
		int i = Compare(data, node->data);

		if (i == 0)
		{
			cout << "Duplicate node found." << endl;
			node->leaf = false;
			return Insert(node->left, data, node, '<');
		}
		else if (i == 1)
		{
			node->leaf = false;
			return Insert(node->left, data, node, '<');
		}
		else if (i == 2)
		{
			node->leaf = false;
			return Insert(node->right, data, node, '>');
		}
	}
}

TreeNode* BinaryTree::Search(TreeNode* node, int data)
{
	if (node->data != data)
	{
		int c = Compare(node->data, data);
	
		if (!isleafNode(node) )		// remember to put this here
		{
			if (c == 1)
			{
				if (node->right != NULL)
					return Search(node->right, data);
				else 
					cout << "Node " << data << " doesn't exist." << endl;
			}
			else if (c == 2)
			{
				if (node->left != NULL)
					return Search(node->left, data);
				else 
					cout << "Node " << data << " doesn't exist." << endl;
			}
		}
		else
		{
			cout << "Node " << data << " doesn't exist." << endl;
			return NULL;
		}
	}

	else if (node->data == data)
	{
		cout << "Match located.\n";
		cout << node->data << " equals " << data << endl;
		return node;
	}

}

NodePack BinaryTree::oneChildNode(TreeNode* node)
{
	if (node != NULL)
	{
		NodePack temp;
		if (node->left != NULL && node->right == NULL)
		{
			cout << "Has a left child." << endl;
			temp.left = node->left;
			temp.right = NULL;
			return temp;
		}
		else if (node->left == NULL && node->right != NULL)
		{
			cout << "Has a right child." << endl;
			temp.right = node->right;
			temp.left = NULL;
			return (temp);
		}

		else if (isleafNode(node) )
		{
			temp.left = temp.right = NULL;
			return temp;
		}

		else 
		{
			cout << "Node has two or more children." << endl;
			return twoChildNode(node);
		}
	}

	else if (node == NULL || node->data == 0)
	{
		NodePack invalid;
		cout << "Node is invalid." << endl;
		return invalid;
	}
}


NodePack BinaryTree::twoChildNode(TreeNode* node)
{
	NodePack temp;
	if (node != NULL)
	{
		if (node->left != NULL && node->right != NULL)
		{
			cout << "Node has two children." << endl;
			temp.left = node->left;
			temp.right = node->right;
			return temp;
		}

		else if (isleafNode(node) )
		{
			temp.left = temp.right = NULL;
			return temp;
		}

		else 
		{
			cout << "Node has less than two children." << endl;
			return oneChildNode(node);
		}
	}

	else if (node == NULL || node->data == 0)
	{
		cout << "Node is invalid." << endl;
		return temp;
	}
}

int Compare(int x, int y)
{
	if (EQUAL_TO(x, y) )		// this is a must in this case for Equal_To to be first instead of second
		return 0;
	else if (LESS_THAN(x, y) == x)
		return 1;
	else if (GREATER_THAN(x, y) == x)
		return 2;
}

void ExecuteBinaryTree()
{
/*	BinaryTree tree;
	tree.InsertRootNode(5);

	tree.InsertNode(7);
	tree.InsertNode(3);
	tree.InsertNode(3);
	
	cout << "Number of nodes: " << tree.Count() << endl;
	cout << "\t\t\t" << tree.getRoot()->data << endl;
	cout << "\t\t      " <<tree.getRoot()->left->data << "\t  " << tree.getRoot()->right->data << endl;
	cout << "\t            " <<tree.getRoot()->left->left->data << endl;*/

	// Test 1
/*
	BinaryTree newTree;
	newTree.InsertRootNode(10);

	newTree.InsertNode(15);
	newTree.InsertNode(17);
	newTree.InsertNode(11);

	newTree.InsertNode(8);
	newTree.InsertNode(5);
	newTree.InsertNode(9);
	newTree.InsertNode(16);
	newTree.InsertNode(19);
	newTree.InsertNode(20);
	newTree.InsertNode(18);
	newTree.InsertNode(12);
	newTree.InsertNode(13);
	newTree.InsertNode(14);
	newTree.InsertNode(3);
	newTree.InsertNode(4);

	cout << newTree.getRoot()->data << endl;
	cout << newTree.getRoot()->left->data << endl;
	cout << newTree.getRoot()->left->left->data << endl;
	cout << newTree.getRoot()->left->right->data << endl;

	cout << newTree.getRoot()->right->data << endl;
	cout << newTree.getRoot()->right->right->data << endl;
	cout << newTree.getRoot()->right->left->data << endl;
	
	newTree.RemoveNode(8);
	newTree.SearchTree(8);
	cout << "\n" << newTree.Count() << endl;
*/
	// Test 2
/*#pragma region Tree2
	BinaryTree tree;
	tree.InsertRootNode(30);

	tree.InsertNode(20);
	tree.InsertNode(15);
	tree.InsertNode(25);
	tree.InsertNode(23);
	tree.InsertNode(10);
	tree.InsertNode(18);
	tree.InsertNode(19);

	tree.InsertNode(40);
	tree.InsertNode(35);
	tree.InsertNode(32);
	tree.InsertNode(31);
	tree.InsertNode(37);
	tree.InsertNode(50);
	tree.InsertNode(45);
	tree.InsertNode(51);

	tree.RemoveNode(40);
	tree.SearchTree(40);
	tree.RemoveNode(31);
	tree.SearchTree(31);
#pragma endregion*/

	/*
	// Test 3
	BinaryTree tree3;
	tree3.InsertRootNode(5);

	tree3.InsertNode(4);
	tree3.InsertNode(3);
	tree3.InsertNode(2);
	tree3.InsertNode(1);

	tree3.InsertNode(6);
	tree3.InsertNode(7);
	tree3.InsertNode(9);
	tree3.InsertNode(8);
	tree3.InsertNode(12);
	tree3.InsertNode(11);
	tree3.InsertNode(10);

	//tree3.RemoveNode(6);
	//tree3.RemoveNode(12);
	tree3.SearchTree(10);
	tree3.printTree();
	*/

	// test 4
	BinaryTree tree4;
	/*

						 17
					   /     \
					  8       34
				    /  \     /  \
				   5    13  20   68
				  / \  / \   \   \
				 2	 7 11 16  25  90
				/ \	/         /   / \
			  1   3 6        23  70  100

	*/
	tree4.InsertRootNode(17);
	tree4.InsertNode(8);
	tree4.InsertNode(5);
	tree4.InsertNode(13);
	tree4.InsertNode(11);
	tree4.InsertNode(16);
	tree4.InsertNode(2);
	tree4.InsertNode(7);
	tree4.InsertNode(1);
	tree4.InsertNode(3);
	tree4.InsertNode(6);

	tree4.InsertNode(34);
	tree4.InsertNode(20);
	tree4.InsertNode(68);
	tree4.InsertNode(25);
	tree4.InsertNode(23);
	tree4.InsertNode(90);
	tree4.InsertNode(70);
	tree4.InsertNode(100);

	tree4.printTree();
}