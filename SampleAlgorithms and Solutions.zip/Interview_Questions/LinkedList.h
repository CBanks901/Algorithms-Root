#include "Utilities.h"

struct Node
{
	Node* next, *previous;
	int element;

	Node()
	{
		next = previous = NULL;
		element = 0;
	}

	Node(int element)
	{
		next = previous = NULL;
		this->element = element;
	}
};

class LinkedList
{
public:
	LinkedList();									// costructor
	~LinkedList();									// destructor
	LinkedList(LinkedList&);						// copy constructor
	void addFirst(int element);						// adds a new element at the beginning of the list
	void addLast(int element);							// adds a new element to the list at the end
	void add(int element, int index);				// adds a new elemetn at a specified postion 
	void removeLast();								// removes the last element from the list
	void removeFirst();								// removes the first element from the list
	void removeE(int element);						// removes a element based on its value
	void removeI(int index);							// removes a element based on the index parameter
	bool checkElement(int element);					// checks the element in the list
	int getsize();									// returns the size
	int getindex(int element);						// returns the index
	void printList();								// prints out the contents of the list

private:
	Node* head;
	Node* tail;
	int size;
};

/*		FIX LATER
void ExecuteSampleList()
{
	LinkedList list;
	
	(list).addLast(85);
	(list).removeFirst();
	(list).addFirst(5);
	(list).addFirst(10);
	(list).addFirst(11);
	(list).addFirst(19);

	(list).addLast(7);
	(list).addLast(22);
	(list).addLast(50);
	(list).add(17, 3);
	(list).removeLast();
	(list).removeFirst();
	(list).printList();

	(list).removeE(11);
	(list).removeI(5);
	(list).printList();
};
*/