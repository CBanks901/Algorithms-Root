#include "HashTable.h"

HashTable::HashTable()
{
	tablesize = 5;

	entry = new HashData*[tablesize];
	for (int i = 0; i < tablesize; i++)
		entry[i] = NULL;
}

HashTable::HashTable(int size)
{
	tablesize = size;

	entry = new HashData*[size];

	for (int i = 0; i < size; i++)
		entry[i] = NULL;
}

HashTable::~HashTable()
{
	for (int i = 0; i < tablesize; i++)
		if (entry[i] != NULL)
			delete entry[i];
	delete [] entry;
}

void HashTable::Hash(int key, string value)
{
	int hash = (key % tablesize);

	while (entry[hash] != NULL && entry[hash]->getkey() != key)
	{
		hash = (hash + 1) % tablesize;
	}
	if (entry[hash] != NULL)
		delete entry[hash];

	entry[hash] = new HashData();
	entry[hash]->value = value;
	entry[hash]->key = key;

}

int HashTable::getItem(int key)
{
	int hash = (key % tablesize);

	while (entry[hash] != NULL && entry[hash]->getkey() != key)
	{
		hash = (hash + 1) % tablesize;
	}

	if (entry[hash] == NULL)
	{
		cout << "Item isn't in table.\n";
		return -1;
	}
	else
	{
		cout << "Index: " << hash << " " << entry[hash]->getValue() << endl;
		return entry[hash]->getkey();
	}
}

int HashTable::getTableSize()
{
	return tablesize;
}
void ExecuteHash()
{
	HashTable myTable;

	myTable.Hash(5, "Christian");
	myTable.Hash(3, "Kyrie");

	myTable.getItem(5);
	myTable.getItem(3);
}
