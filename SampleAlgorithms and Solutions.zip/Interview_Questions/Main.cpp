// Note: These interview solutions are from cracking the code interview
#include "Question_1.h"
#include "Question_2.h"
#include "FriendExample.h"
#include "LinkedList.h"
#include "Stack.h"
#include "HashTable.h"
#include "Singleton.h"
#include "Queue.h"
#include "BinaryTree.h"
#include "Factory.h"

#include "Vector.h"
#include "MergeSort.h"
using namespace std;

void InsertionSort(int arr[], int arraysize);
void quickSort(int arr[], int left, int right);
void ExecuteQuickSort();
void ExecuteInsertionSort();
void MergeSortA(int arr[], int left, int right, int size);

void BinarySearch(int arr[], int key, int size);
void ExecuteBinarySearch();
int getDigits(int value);

int Add(int x, int y)
{
    // Iterate till there is no carry  
    while (y != 0)
    {
        // carry now contains common set bits of x and y
        int carry = x & y;  
 
        // Sum of bits of x and y where at least one of the bits is not set
        x = x ^ y; 
		cout << x << endl;
 
        // Carry is shifted by one so that adding it to x gives the required sum
        y = carry << 1;
    }
    return x;
}

int Equal(int x, int y)
{
	return (~x ^ y);		// the return value becomes -1 (if true)
	// or 
	//return (x ^ y);		// the return value becomes 0 (if true)
}

void main()
{
	srand(unsigned int(time(NULL) ) );
	//Question1Scenario();		// handles the case for the first question

/*#pragma region ArraySection
	char str[] = {'c', 'h', 'r', 'i', 's', '\0'};
	char str2[] = "Bleach";
	reverseS(str2);
#pragma endregion*/

	// ExecuteExample();	// For the friend class

	// ExecuteSampleList();	// Needs to be fixed

	// ExecuteStack();
	
	// ExecuteHash();

	// ExecuteBinaryTree();

	// ExecuteQueue();

	// ExecuteSingleton();

	// ExecuteFactory();

	// ExecuteVector();

	// ExecuteMergeSort();

	// ExecuteCharMergerSort();

	// ExecuteInsertionSort();
	
	// ExecuteQuickSort();

	// ExecuteBinarySearch();

/*	int value(3542), i(0), size(getDigits(value));
	stringstream counter;
	counter << value;
	int *arr = new int[size];

	do
	{
		cout << counter.str().at(i++) << endl;
	} while (i < size);
	
	for (int v(0); v < size; v++)
	{
		arr[v] = counter.str().at(v) - '0';
		cout << "Modified value: " << arr[v] << endl;
	}
	
	delete arr;
	cout << Add(10, 6) << endl; */

	/*cout << "Please choose a list size: ";
	int size(0), counter(0);
	cin >> size;

	int *arr = new int[size];
	while (counter < size)
	{
		cout << "\a" << counter << ": ";
		cin >> arr[counter++];
	}

	for (int p(0); p <= size-1; ++p)
		cout << arr[p] << endl;

	MergeSortA(arr, 0, size-1, size-1);

	delete arr;*/
	cout << "\aPress any key to continue...." << endl;
	_getch();
	return;
}

void InsertionSort(int arr[], int arraysize)
{
	int counter(0);
	for (int i = 0; i <= arraysize-1; ++i)
	{
		if (arr[i] >= arr[i+1])
		{
			swap(arr[i], arr[i+1]);
		}

		counter = i;
		while (counter > 0)
		{
			if (arr[counter] <= arr[counter-1])
			{
				swap(arr[counter], arr[counter-1]);
			}
			--counter;
		}
	}
}

void quickSort(int arr[], int left, int right) 
{
      int i = left, j = right;
      int tmp;
      int pivot = arr[(left + right) / 2];
 
      /* partition */
      while (i <= j) {
            while (arr[i] < pivot)
                  i++;
            while (arr[j] > pivot)
                  j--;
            if (i <= j) {
                  tmp = arr[i];
                  arr[i] = arr[j];
                  arr[j] = tmp;
                  i++;
                  j--;
            }
      };
 
	  cout << "I: " << i << "\t J: " << j << endl;
      /* recursion */
      if (left < j)
	  {
            quickSort(arr, left, j);
	  }
      if (i < right)
	  {
            quickSort(arr, i, right);
	  }
}

void BinarySearch(int arr[], int key, int size)
{
	int mid(0), attempt(0), low(0), high(size);
	while (low <= high)
	{
		mid = (high + low)/2;
		if (arr[mid] == key)
		{
			cout << "Match found!" << endl;
			break;
		}
		else if (arr[mid] < key)
			low = mid + 1;
		else if (arr[mid] > key )
			high = mid - 1;
		cout << "Attempt number " << ++attempt << endl;
	}

	if (low > high || high < low)
			cout << "Unable to find a match." << endl;
}

void ExecuteBinarySearch()
{
	int arr[] = {10, 5, 3, 5, 3, 2, 4, 1, 7, 8}; 

	int arraysize = sizeof(arr)/sizeof(arr[0]) -1;
	
	int i(0);
	for (i; i <= arraysize; ++i)
	{
		cout << arr[i] << endl;
		getDigits(arr[i]);
	}

	InsertionSort(arr, arraysize);
	cout << "Sorted list." << endl;
	for (int i(0); i <= arraysize; ++i)
		cout << arr[i] << endl;

	char repeat('Y');
	
	while (repeat == 'Y' || repeat == 'y')
	{
		cout << "If you want to look for a value type it in now: ";
		int value(0);
		cin >> value;


	if (value > 0)
		BinarySearch(arr, value, arraysize);

		cout << "Try again? Y or Y: ";
		cin >> repeat;
		while (repeat != 'Y' && repeat != 'y' && repeat != 'n' && repeat != 'N')
		{
			cout << "\a Error. Y, y, N or N: ";
			cin >> repeat;
		}
	}
}

void ExecuteInsertionSort()
{
	int arrayvalues[] = {10, 5, 3, 5, 7};
	
	int arraysize = sizeof(arrayvalues)/sizeof(arrayvalues[0]) - 1;
	cout << "Unsorted list." << endl;
	for (int p(0); p <= arraysize; ++p)
		cout << arrayvalues[p] << endl;

	cout << "Attempting to sort....." << endl;
	InsertionSort(arrayvalues, arraysize);

	cout << "Sorted list." << endl;
	for (int i(0); i <= arraysize; ++i)
		cout << arrayvalues[i] << endl;
}

void ExecuteQuickSort()
{
	int arrayvalues[] = {2, 9, 1, 6, 4, 5, 1};
	
	int arraysize = sizeof(arrayvalues)/sizeof(arrayvalues[0]) -1;
	cout << "Unsorted list." << endl;
	for (int p(0); p <= arraysize; ++p)
		cout << arrayvalues[p] << endl;

	cout << "Attempting to sort....." << endl;
	quickSort(arrayvalues, 0, arraysize);

	cout << "Sorted list." << endl;
	for (int i(0); i <= arraysize; ++i)
		cout << arrayvalues[i] << endl;
}

int getDigits(int value)
{
	if (value < 10)
		value = 1;
	else if (value >= 10 && value < 100)
		value = 2;
	else if (value >= 100 && value < 1000)
		value = 3;
	else if (value >= 1000 && value < 10000)
		value = 4;
	else if (value >= 10000 && value < 100000)
		value = 5;
	else if (value >= 100000 && value < 1000000)
		value = 6;
	switch (value)
	{
	case 1:
		cout << "Value has " << value << " significant digit." << endl;
		break;
	case 2:
		cout << "Value has " << value << " significant digits." << endl;
		break;
	case 3:
		cout << "Value has " << value << " significant digits." << endl;
		break;
	case 4: 
		cout << "Value has " << value << " significant digits." << endl;
		break;
	case 5:
		cout << "Value has " << value << " significant digits." << endl;
		break;
	case 6:
		cout << "Value has " << value << " significant digits." << endl;
		break;
	}

	return value;
}

void MergeSortA(int arr[], int left, int right, int size)
{
	if ( (left + right) > 2)
	{
		int pivot = left + right /2;

		MergeSortA(arr, left, pivot, pivot);
		MergeSortA(arr, pivot, pivot+1, pivot);
	}
}