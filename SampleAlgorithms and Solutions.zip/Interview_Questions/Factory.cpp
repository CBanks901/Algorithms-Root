#include "Factory.h"

string ToyMaterials::metal = "metal";
string ToyMaterials::rubber = "rubber";
string ToyMaterials::plastic = "plastic";
Factory* Factory::instance = NULL;

int Factory::getage()
{
	return age;
}

void Factory::setAge(int age)
{
	(*this).age = age;
}

void Factory::PrintType()
{
	if (Factory::instance)
		cout << "Type is: " << type << endl;
	else 
		cout << "Undefined type." << endl;
}

void Factory::setType(string type)
{
	(*this).type = type;
}

Factory* Factory::getInstance()
{
	if (instance)
		return instance;
	else 
		return NULL;
}

#pragma region ToyRegion
Toy::Toy()
{
	make = "empty";
	int random = rand()%3;
	
	switch (random)
	{
	case 0:
		setMake(ToyMaterials::rubber);
		break;
	case 1:
		setMake(ToyMaterials::metal);
		break;
	case 2:
		setMake(ToyMaterials::plastic);
		break;
	default:
		setMake(ToyMaterials::plastic);
		break;
	}
}

Toy::Toy(string make)
{
	setMake(make);
}

void Toy::setMake(string make)
{
	(*this).make = make;
	PrintMake();
}

void Toy::PrintMake()
{
	cout << "This toy is made of: " << make << endl;
}

void Toy::setType(string type)
{
	(*this).type = type;
}
#pragma endregion

#pragma region AlcoholRegion
Alcohol::Alcohol()
{
	int random = rand()%3;

	switch(random)
	{
	case 0:
		setFlavor("CHARDONNAY");
		break;
	case 1:
		setFlavor("PINOT" " " "NOIR");
		break;
	case 2:
		setFlavor("RIESLING");
		break;
	default:
		setFlavor("Wine");
	}
	PrintBevarage();
}

Alcohol::Alcohol(string a)
{
	setFlavor(a);
	PrintBevarage();
}

void Alcohol::setType(string type)
{
	(*this).type = type;
}

void Alcohol::PrintBevarage()
{
	cout << "Your bevarge: " << flavor << endl;
}

void Alcohol::setFlavor(string a)
{
	flavor = a;
}
#pragma endregion

#pragma region CarRegion
Car::Car()
{
	int random = rand() %10;

	switch(random)
	{
	case 0:
		setMake("Volkswagen");
		break;
	case 1:
		setMake("Honda");
		break;
	case 2:
		setMake("Toyota");
		break;
	case 3:
		setMake("Hyundai");
		break;
	case 4:
		setMake("Nissan");
		break;
	case 5:
		setMake("Geely");
		break;
	case 6:
		setMake("GM");
		break;
	case 7:
		setMake("PSA");
		break;
	case 8:
		setMake("TATA");
		break;
	case 9:
		setMake("FCA");
		break;
	default:
		setMake("FCA");
	}
	PrintMake();
}

Car::Car(string make)
{
	setMake(make);
	PrintMake();
}

void Car::PrintMake()
{
	cout << "Car is " << make << endl;
}

void Car::setMake(string make)
{
	(*this).make = make;
}

void Car::setType(string type)
{
	(*this).type = type;
}
#pragma endregion

Factory* Factory::makedecision(int age)
{
	if (Child(age) == true)
	{
		cout << "\aChild here" << endl;

		cout << "\aWhat kind of toy do you want? rubber(0), metal(1), plastic(2), random(3): ";
		int input;
		cin >> input;
		while (input < 0 || input > 3)
		{
			cout << "\aPlease enter a proper value: ";
			cin >> input;
		}

		if (instance)
			delete instance;

		if (input == 0)
			instance =  new Toy(ToyMaterials::rubber);
		else if (input == 1)
			instance = new Toy(ToyMaterials::metal);
		else if (input == 2)
			instance = new Toy(ToyMaterials::plastic);
		else if (input == 3)
			instance = new Toy();
		instance->setType("Toy");
		return instance;
	}

	else if (Teen(age) == true)
	{
		cout << "\aTeen here." << endl;

		if (instance)
			delete instance;

		int input;
		cout << "\aEnter 0 for Volkswagen, 1 for Honda, 2 for Toyota, 3 for Hyundai,";
		cout << " 4 for Nissan, 5 for Geely, 6 for GM, 7 for PSA, 8 for TATA, 9 for FCA or 10 for random: ";

		cin >> input;

		while (input < 0 || input > 10)
		{
			cout << "\aInvalid argument. Please enter a proper value" << endl;
			cin >> input;
		}

		switch (input)
		{
		case 0:
			instance = new Car("Volkswagen");
			break;
		case 1:
			instance = new Car("Honda");
			break;
		case 2:
			instance = new Car("Toyota");
			break;
		case 3:
			instance = new Car("Hyundai");
			break;
		case 4:
			instance = new Car("Nissan");
			break;
		case 5:
			instance = new Car("Geely");
			break;
		case 6:
			instance = new Car("GM");
			break;
		case 7:
			instance = new Car("PSA");
			break;
		case 8:
			instance = new Car("TATA");
			break;
		case 9:
			instance = new Car("FCA");
			break;
		case 10:
			instance = new Car();
			break;
		default:
			instance = new Car();
			break;
		}
		instance->setType("Car");
		return instance;
	}

	else if (Adult(age) == true)
	{
		cout << "\aAdult here." << endl;
		
		int input;
		cout << "\aEnter 0 for CHARDONNAY, 1 for PINOT" " " "NOIR, 2 for RIESLING, 3 for Random: ";
		cin >> input;

		while (input < 0 && input > 3)
		{
			cout << "\aPlease enter a proper value: " << endl;
			cin >> input;
		}
		
		if (instance)
			delete instance;

		switch(input)
		{
		case 0:
			instance = new Alcohol("CHARDONNAY");
			break;
		case 1:
			instance = new Alcohol("PINOT" " " "NOIR");
			break;
		case 2:
			instance = new Alcohol("RIESLING");
			break;
		case 3:
			instance = new Alcohol();
			break;
		default:
			instance = new Alcohol();
		}

		instance->setType("Alcohol");
		return instance;
	}

	else 
		cout << "Invalid input." << endl;
}

void ExecuteFactory()
{
	cout << "\aEnter your age please: ";
	int age = 0;
	cin >> age;
	
	while (age < 0 || age > 100)
	{
		cout << "\aThat age value is out of range.\n Please enter a age value in the range of 0 to 100: " << endl;
		cin >> age;
	}

	/* Unhighlight to change the color
	HANDLE hstout = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hstout, FOREGROUND_GREEN|FOREGROUND_BLUE);*/


	Factory::getInstance()->makedecision(age);
	Factory::getInstance()->setAge(age);
	cout << "Age of the person in question is: " << Factory::getInstance()->getage() << endl;
	Factory::getInstance()->PrintType();

	cout << "\aRepeat? Y or N" << endl;
	char input;
	cin >> input;

	if (input == 'Y')
		ExecuteFactory();
	else if (input == 'N')
		return;
	else
	{
		cout << "\aInput invalid. Please enter Y or N: ";

		cin >> input;
		if (input == 'Y')
			ExecuteFactory();
		if (input == 'N')
			return;
		while (input != 'Y' || input != 'N')
		{
			cout << "\aTry again: ";
			cin >> input;
			if (input == 'Y')
				break;
			else if (input == 'N')
				break;
		}

		if (input == 'Y')
			ExecuteFactory();
		else if (input == 'N')
			return;
	}
}